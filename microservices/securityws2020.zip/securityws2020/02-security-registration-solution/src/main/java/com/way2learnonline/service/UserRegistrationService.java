package com.way2learnonline.service;

import com.way2learnonline.model.MyAppUser;

public interface UserRegistrationService {

	void createUser(MyAppUser user);
	
}
